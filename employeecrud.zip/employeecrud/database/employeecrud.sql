-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 21, 2023 at 12:25 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `employeecrud`
--

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `id` int(11) NOT NULL,
  `name` varchar(55) NOT NULL,
  `gender` varchar(8) NOT NULL,
  `email` varchar(66) NOT NULL,
  `occupation` varchar(77) NOT NULL,
  `education_level` varchar(77) NOT NULL,
  `last_job` varchar(66) NOT NULL,
  `joining_date` date DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`id`, `name`, `gender`, `email`, `occupation`, `education_level`, `last_job`, `joining_date`) VALUES
(72, 'Irfanullah', 'male', 'i.raufi.afg@gmail.com', 'Student', 'BSC', 'Driver', '2023-03-20'),
(75, 'Khan', 'male', 'khan@gmail.com', 'student', 'master', 'CEO', '2023-03-17'),
(111, 'nazif', 'male', 'nazif@gmail.com', 'student', 'master', 'CEO', '2023-03-16'),
(112, 'jamel', 'male', 'jamel@gmail.com', 'student', 'master', 'CEO', '2023-03-15'),
(125, 'Ridwanullah', 'male', 'r.raufi.afg@gmail.com', 'Engineer', 'BSCS', 'Student', '2023-03-21'),
(126, 'tawheed', 'male', 't.raufi.afg@gmail.com', 'shopkeeper', 'BSSE', 'Student', '2023-03-21');

-- --------------------------------------------------------

--
-- Table structure for table `lastjob`
--

CREATE TABLE `lastjob` (
  `id` int(11) NOT NULL,
  `role` varchar(55) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `lastjob`
--

INSERT INTO `lastjob` (`id`, `role`) VALUES
(1, 'Manager'),
(3, 'Teacher'),
(5, 'Student'),
(6, 'Driver'),
(7, 'CEO');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `lastjob`
--
ALTER TABLE `lastjob`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `employee`
--
ALTER TABLE `employee`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=127;

--
-- AUTO_INCREMENT for table `lastjob`
--
ALTER TABLE `lastjob`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
