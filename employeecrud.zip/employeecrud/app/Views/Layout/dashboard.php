<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <script
    src="https://code.jquery.com/jquery-3.6.4.min.js"
    integrity="sha256-oP6HI9z1XaZNBrJURtCoUT5SUnxFr8s3BzRl+cbzUq8="
    crossorigin="anonymous"></script>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css" integrity="sha512-SzlrxWUlpfuzQ+pcUCosxcglQRNAq/DZjVsC0lE40xsADsfeQoEypE+enwcOiGjk/bSuGGKHEyjSoQ1zVisanQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js" integrity="sha512-GsLlZN/3F2ErC5ifS5QtgpiJtWd43JWSuIgh7mbzZ8zBps+dvLusV+eNQATqgA/HdeKFVgA5v3S/cIrLF7QnIg==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.4/js/dataTables.bootstrap4.min.js"></script>
    
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>dashboard</title>
  
</head>
<body>
    
<div class="container p-4">
     <div class="row">
        <div class="col-md-6">
        <div style="width:400px;margin:auto;">
           <canvas id="myChart1"></canvas>
         </div>
        </div>
        <div class="col-md-6">
        <div style="width:400px;margin:auto;">
           <canvas id="myChart2"></canvas>
         </div>
        </div>
     </div>
     <div class="row">
        <div class="col-md-6">
        <div style="width:400px;margin:auto;">
           <canvas id="myChart3"></canvas>
         </div>
        </div>
        <div class="col-md-6">
        <div style="width:400px;margin:auto;">
           <canvas id="myChart4"></canvas>
         </div>
        </div>
     </div>
</div>


<script>
    $(document).ready(function(){



        loadchart('pie','#myChart1')
        loadchart('doughnut','#myChart2')
        loadchart('line','#myChart3')
        loadchart('bar','#myChart4')
    function loadchart(CharType,element){
   
  const ctx = $(element);
     var monday=0,tuesday=0,wednesday=0,thursday=0,friday=0;
  $.ajax({
    url:'getCount',
    method:'GET',
    success:function(data)
    {
        tuesday=data
        
    }
  })
  $.ajax({
    url:'getCount1',
    method:'GET',
    success:function(data)
    {
      monday=data
      
        
    }
  })
  $.ajax({
    url:'getCount2',
    method:'GET',
    success:function(data)
    {
      friday=data
        
    }
  })
  $.ajax({
    url:'getCount3',
    method:'GET',
    success:function(data)
    {
      thursday=data
        
    }
  })
  $.ajax({
    url:'getCount4',
    method:'GET',
    success:function(data)
    {
      wednesday=data
        
    }
  })

setTimeout(function(){
  new Chart(ctx, {
    type: CharType,
    data: {
      labels: ['wednesday', 'Tursday', 'Friday', 'Monday','Tuesday'],
      datasets: [{
        label: "employee Hiring",
        data: [wednesday, thursday, friday,monday,tuesday],
        borderWidth: 1
      }]
    },
    options: {
      scales: {
        y: {
          beginAtZero: true
        }
      }
    }
  });
},1000)
 
   
    }




    })
</script>
</body>
</html>