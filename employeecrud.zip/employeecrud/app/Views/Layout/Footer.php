





<script>

    $(document).ready(function (event) {
        

    $('#example').DataTable();

   
       



});



</script>
</body>
</html>