<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <script
    src="https://code.jquery.com/jquery-3.6.4.min.js"
    integrity="sha256-oP6HI9z1XaZNBrJURtCoUT5SUnxFr8s3BzRl+cbzUq8="
    crossorigin="anonymous"></script>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css" integrity="sha512-SzlrxWUlpfuzQ+pcUCosxcglQRNAq/DZjVsC0lE40xsADsfeQoEypE+enwcOiGjk/bSuGGKHEyjSoQ1zVisanQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js" integrity="sha512-GsLlZN/3F2ErC5ifS5QtgpiJtWd43JWSuIgh7mbzZ8zBps+dvLusV+eNQATqgA/HdeKFVgA5v3S/cIrLF7QnIg==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.4/js/dataTables.bootstrap4.min.js"></script>
    
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EmployeeManagement</title>
    <style>
      /* #example_info,.dataTables_empty,.col-md-6,#example_paginate{
        display: none;
      } */
    </style>
</head>
<body>

<!-- Button trigger modal -->


<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel" id='formtext'>Add New Employee</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <form action="" method="post" id="addemp"  >
                <div class="form-group d-none">
                  <input type="text" name="id" id="id">
                </div>
              <div class="form-group">
                   <label  class="my-1" for="">EmployeeName</label>
                   <input type="text" id="name" class="form-control" name="name" value="<?=isset($employee->name) ? $employee->name : '' ?>">
                   <p id="nameerror" style="display:none" class="text-danger">name is required</p>
              </div>
              <div class="form-group">
                 <label  class="my-1" for="">Gender</label>
              <select class="form-select" id="gender" name="gender" aria-label="Default select example">
              <option value="">Select Gender</option>
              <option value="male">Male</option>
              <option value="female">Female</option>
             
              </select>
              <p id="gendererror" style="display:none" class="text-danger">gender is required</p>
              </div>
              <div class="form-group">
                   <label  class="my-1" for="">Email</label>
                   <input type="email" id="email" class="form-control" name="email">
                   
              </div>
              <p id="emailError" style="display:none;color:red">This email already exist</p>

              <div class="form-group">
                   <label  class="my-1" for="">Occupation</label>
                   <input type="text" id="occupation" class="form-control" name="occupation">
              </div>
              <p id="occupationerror" style="display:none" class="text-danger">occupation is required</p>
              <div class="form-group">
                   <label  class="my-1" for="">Education_level</label>
                   <input type="text" id="educationlevel" class="form-control" name="education_level">
              </div>
              <p id="educationerror" style="display:none" class="text-danger">education is required</p>
              <div class="form-group">
                   <label  class="my-1" for="">Last-Job</label>
             <select class="form-select" id="lastjob" name="last_job" aria-label="Default select example">
              <option value="">select last job</option>
              </select>
              </div>
              <p id="lastjoberror" style="display:none" class="text-danger">last job is required</p>
              <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary" >Add Employee</button>
      </div>
        </form>
         
      </div>
     
    </div>
  </div>
</div>



<!-- Modal for employee details-->
<div class="modal fade" id="exampleModal2" tabindex="-1" aria-labelledby="exampleModalLabel2" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Employee Details</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <form action="" method="post" id="addnewemp">
              <div class="form-group">
                   <label  class="my-1" for="">EmployeeName:<span  class="fw-bolder mx-2" id="name1"></span></label>
                  
                  
              </div>
              <div class="form-group">
                 <label  class="my-1" for="">Gender:<span id="gender1" class="fw-bolder mx-2"></span></label>
                
              </div>
              <div class="form-group">
                 <label  class="my-1" for="">email:<span id="email1" class="fw-bolder mx-2"></span></label>
                
              </div>
              <div class="form-group">
                   <label  class="my-1" for="">Occupation:<span id="occupation1" class="fw-bolder mx-2"></span></label>
                 
              </div>
              <div class="form-group">
                   <label  class="my-1" for="">Education_level: <span id="educationlevel1" class="fw-bolder mx-2"></span></label>
                   
              </div>
              <div class="form-group">
                   <label  class="my-1" for="">Last-Job:<span id="lastjob1" class="fw-bolder mx-2"></span></label>
                  
              </div>
        </form>
         
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
       
      </div>
    </div>
  </div>
</div>

<!-- 
<div class="modal fade" id="exampleModal3" tabindex="-1" aria-labelledby="exampleModalLabel3" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Edit Employee</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <form action="" method="post" id="editform" >
        <div class="form-group d-none">
                   <input type="number" id="empid" class="form-control">
              </div>
              <div class="form-group">
                   <label  class="my-1" for="">EmployeeName</label>
                   <input type="text" id="name2" name="name" class="form-control">
                   <p id="nameerror" style="display:none" class="text-danger">name is required</p>
              </div>
              <div class="form-group">
                 <label  class="my-1" for="">Gender</label>
              <select class="form-select" id="gender2" name="gender" aria-label="Default select example">
              <option value="">Select Gender</option>
              <option value="male">Male</option>
              <option value="female">Female</option>
             
              </select>
              <p id="gendererror" style="display:none" class="text-danger">gender is required</p>
              </div>
              <div class="form-group">
                   <label  class="my-1" for="">email</label>
                   <input type="email" id="email2"  name="email" class="form-control">
              </div>
              <p id="emailerror" style="display:none" class="text-danger">provide unique email</p>
              <div class="form-group">
                   <label  class="my-1" for="">Occupation</label>
                   <input type="text" id="occupation2" name="occupation" class="form-control">
              </div>
              
              <p id="occupationerror" style="display:none" class="text-danger">occupation is required</p>
              <div class="form-group">
                   <label  class="my-1" for="">Education_level</label>
                   <input type="text" id="educationlevel2" name="education_level" class="form-control">
              </div>
              <p id="educationerror" style="display:none" class="text-danger">education is required</p>
              <div class="form-group">
                   <label  class="my-1" for="">Last-Job</label>
                   <select class="form-select" id="lastjob2" name="last_job" aria-label="Default select example">
                       <option value="">select last job</option>
                   </select>
              </div>
              <p id="lastjoberror" style="display:none" class="text-danger">last job is required</p>
              <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary" >Save Edit</button>
      </div>
        </form>
         
      </div>
   
    </div>
  </div>
</div> -->


<div class="p-3">
<div class="container">
       <div class="row ">
        <div class="col-md-10 my-2  d-flex justify-content-between">
           <a href="generate-pdf-all" class="btn btn-primary btn-sm">Generate PDF</a>
           <h6 class="btn btn-primary btn-sm  " data-bs-toggle="modal" data-bs-target="#exampleModal"><i class="fa-solid fa-plus"></i> Add Employee</h3>
           </div>
           
        
    
          <table id="example" class="table table-striped table-bordered" >
        <thead class="bg-primary text-white">
          
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Gender</th>
                <th>Email</th>
                <th>Occupation</th>
                <th>Education-Level</th>
                <th>last-job</th>
                <th>date-of-joining</th>
                <th>Action</th>
                
            </tr>
        </thead>
        <tbody id="all-employee">
            
      
 
   
  
    
        
        </tbody>
       
    </table>
          </div>

       </div>
</div>



<script>

    $(document).ready(function () {
        var submitform=false;
         $("#email").change(function(){
              var email=$('#email').val()
              if(email!='')
              {
                  $.ajax({
                    url:"email/check_email",
                    method:"POST",
                    data:{'email':email},
                    success:function(data){
                       if(data=='yes')
                       {
                        $("#emailError").show();
                          
                       }else if(data=='no'){
                        submitform=true
                        $("#emailError").hide();
                          
                       }
                    }
                  })
              }
         })
    
    loadstudents()
    $('#all_record').click(function(){
      loadstudents()
     
    })
    $(document).on('click','.btn-delete',function(){
                 var emp_id=$(this).closest('tr').find('.emp_id').text()
                 $.ajax({
                  method:"POST",
                  url:'employee/delete_emp',
                  data:{'emp_id':emp_id},
                  success:function(data){
                      console.log(data)
                  }
                 })
                 
    })
    $(document).on('click','.btn-edit',function(e){
                      
                    e.preventDefault()
                 var emp_id=$(this).closest('tr').find('.emp_id').text()
                 
                 $.ajax({
                  method:"POST",
                  url:'employee/edit_emp',
                  data:{'emp_id':emp_id},
                  success:function(data)
                  {
                     
                    
                    $.each(data,function(key,value){
                        $("#id").val(value['id'])
                        $('#name').val(value['name'])
                        $('#gender').val(value['gender'])
                        $('#email').val(value['email'])
                        $('#occupation').val(value['occupation'])
                        $('#educationlevel').val(value['education_level'])
                        $('#lastjob').html(
                          "<option selected value="+value['last_job']+">"+
                        
                                     value['last_job']
                        +"</option>")
                       
                    
                      })
                      loadAlljobsEdit()
                  }
                 })
                 
    })
    $(document).on('click','.btn-view',function(){
                 var emp_id=$(this).closest('tr').find('.emp_id').text()
                 $.ajax({
                  method:"POST",
                  url:'employee/view_emp',
                  data:{'emp_id':emp_id},
                  success:function(data){
                     // console.log(data.employee)
                      $.each(data,function(key,value){
                        $('#name1').text(value['name'])
                        $('#gender1').text(value['gender'])
                        $('#email1').text(value['email'])
                        $('#occupation1').text(value['occupation'])
                        $('#educationlevel1').text(value['education_level'])
                        $('#lastjob1').text(value['last_job'])
                       
                    
                      })

                  }
                 })
                
    })


    function loadstudents()
    {
         $.ajax({
          method:"GET",
          url:"student/getStudents",
          success:function(data){
            $('#all-employee').html('') 
           
            $.each(data.employee,function(key,value){
            $('#all-employee').append("<tr>"+ 
                "<td class='emp_id'>"+value['id'] +"</td>"+
                "<td>"+value['name'] +"</td>"+
                "<td>"+value['gender'] +"</td>"+
                "<td>"+value['email'] +"</td>"+
                "<td>"+value['occupation'] +"</td>"+
                "<td>"+value['education_level'] +"</td>"+
                "<td>"+value['last_job'] +"</td>"+
                "<td>"+value['joining_date'] +"</td>"+
                "<td> <a href='' class='btn btn-danger btn-sm m-1 btn-delete' >"+'<i class="fa-solid fa-trash"></i>'+"</a><a href='' class='btn btn-success  btn-sm btn-edit' data-bs-toggle='modal' data-bs-target='#exampleModal'>"+' <i class="fa-regular fa-pen-to-square"></i>'+" </a> <a href='' class='btn btn-info btn-sm  btn-view' data-bs-toggle='modal' data-bs-target='#exampleModal2'>"+'<i class="fa-solid fa-eye text-white"></i>'+" </a><a href='generate-pdf-single/"+value['id']+"' class='btn btn-primary btn-sm m-1 '>"+'download'+" </a></td>"+
               
                
            +"</tr>")
           
          })
          
          $('#example').DataTable();
          }
         })
    }


    $('#addemp').submit(function(e){
      e.preventDefault()

          let data=$('#addemp').serialize();

         $.ajax({
            method:"POST",
            url:"save",
            data:data,
            success:function(data){
                  $('#exampleModal').modal('hide');
                  $('#exampleModal').find('input').val('');
                  $('#exampleModal').find('select').val('');
                  $('#all-employee').html('');
                  if(data!=0){
                    alert()
                  }else{
                    
                  Swal.fire({
                   position: 'top',
                   icon: 'success',
                   title: 'Employee Added Successfully',
                   showConfirmButton: false,
                   timer: 1500
                    })
                 
                  }
                  loadstudents()        
                  
           }
          
         })
        
    
        
    
        

    })


   
    $("#editform").submit(function(e){
      e.preventDefault()
     alert()

      //  var id=$('#empid').val()
      //   var name=$('#name2').val()
      //   var gender=$('#gender2').val()
      //   var email=$('#email2').val()
      //   var occupation=$('#occupation2').val()
      //   var educationlevel=$('#educationlevel2').val()
      //   var lastjob=$('#lastjob2').val()
      
      
      //   data={
      //       'id':id,
      //       'name':name,
      //       'gender':gender,
      //       'email':email,
      //       'occupation':occupation,
      //       'education_level':educationlevel,
      //       'last_job':lastjob,
      //     }
          let data=$('#editform').serialize();
          



          $.ajax({
            method:"POST",
            url:"save",
            data:data,
            success:function(data){
                  if(data=='yes')
                  {
                      $('#emailerror').show();
                      setTimeout(function(){
                        $('#emailerror').hide();
                      },3000)
                  }else{
                  $('#exampleModal3').modal('hide');
                  $('#exampleModal3').find('input').val('');
                  $('#exampleModal3').find('select').val('');
                  $('#all-employee').html('');
                  Swal.fire({
                      position: 'top',
                      icon: 'success',
                      title: 'Record Edited successfully',
                      showConfirmButton: false,
                      timer: 1500
                     })
                  loadstudents()
                 
                 
                  
           }
          }
            
         })


       
    })

    loadAllName()
    function loadAllName()
    {
      
    $.ajax({
          method:"GET",
          url:"getnames/getAllName",
          success:function(data){
           // console.log(data)
            $.each(data.name,function(key,value){
            $('#all-name').append("<option value="+value['name']+">"+ 
                value['name'] 
            +"</option>")

          })

          }
         })
    }

    loadAllStartDate()
    function loadAllStartDate()
    {
      
    $.ajax({
          method:"GET",
          url:"getdate/getAlldate",
          success:function(data){
           // console.log(data)
            $.each(data.name,function(key,value){
            $('#all-date').append("<option value="+value['joining_date']+">"+ 
                value['joining_date'] 
            +"</option>")

          })

          }
         })
    }

    loadAllLastJob()

    function loadAllLastJob()
    {  $.ajax({
          method:"GET",
          url:"getlastjob/getAllLastjob",
          success:function(data){
            
            $.each(data.lastjobs,function(key,value){
            $('#lastjob').append("<option value="+value['role']+">"+ 
                value['role'] 
            +"</option>")
            

         })

          }
         })}

      function loadAlljobsEdit()
      {
        $.ajax({
          method:"GET",
          url:"getlastjob/getAllLastjob",
          success:function(data){
            
            $.each(data.lastjobs,function(key,value){
            $('#lastjob2').append("<option value="+value['role']+">"+ 
                value['role'] 
            +"</option>")
            

         })

          }
         })
      } 


    $("#filter").click(function(e){
      var last_job= $("#last_job").val()
   
      

       data={
              'last_job':last_job
            }
          $.ajax({
            method:"POST",
            url:"lastjob/getallemp",
           
            data:data,
            success:function(data)
            {
             // console.log(data)
            $.each(data.allemp,function(key,value){
             
              
            $('#all-employee').html("<tr>"+ 
                "<td class=' emp_id'>"+value['id'] +"</td>"+
                "<td>"+value['name'] +"</td>"+
                "<td>"+value['gender'] +"</td>"+
                "<td>"+value['occupation'] +"</td>"+
                "<td>"+value['education_level'] +"</td>"+
                "<td>"+value['last_job'] +"</td>"+
                "<td>"+value['joining_date'] +"</td>"+
                "<td> <a href='' class='btn btn-danger btn-sm  btn-delete' >Delete </a></td>"+
                "<td> <a href='' class='btn btn-success  btn-sm btn-edit' data-bs-toggle='modal' data-bs-target='#exampleModal3'>Edit </a></td>"+
                "<td> <a href='' class='btn btn-info btn-sm  btn-view' data-bs-toggle='modal' data-bs-target='#exampleModal2'>View </a></td>"
            +"</tr>")

          })

            }
          })
       





        
    })

    

   
  

    

  });




</script>




</body>
</html>


